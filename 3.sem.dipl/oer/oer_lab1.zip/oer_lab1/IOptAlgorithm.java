package oer_lab1;

import java.util.Optional;

public interface IOptAlgorithm {
	
	 Optional<BitVector> solve(BitVector initial);

}

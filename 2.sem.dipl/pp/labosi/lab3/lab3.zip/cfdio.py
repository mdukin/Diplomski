import time

def gettime():
    return time.time()
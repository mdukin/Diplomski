gcc main.c myfactory.c
gcc -shared -o parrot.dll parrot.c
gcc -shared -o tiger.dll tiger.c
a tiger mirko parrot modrobradi
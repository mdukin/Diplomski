package ooup_lab3;

public interface CursorObserver {
	
	public void updateCursorLocation(Location loc);
}

package ooup_lab3;

public interface TextObserver {

	public void updateText();
}

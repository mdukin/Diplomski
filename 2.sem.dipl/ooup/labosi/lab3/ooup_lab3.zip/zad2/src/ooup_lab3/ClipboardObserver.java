package ooup_lab3;

public interface ClipboardObserver {
	
	public void updateClipboard();

}

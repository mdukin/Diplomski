package ooup_lab3;

public interface EditAction {

	public void execute_do() ;
	public void execute_undo();

}

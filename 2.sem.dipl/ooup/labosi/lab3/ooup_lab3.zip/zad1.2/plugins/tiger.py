class tiger:
    def __init__(self, name):
        self._name = name

    def name(self):
        return self._name

    def greet(self):
        return "roar!"

    def menu(self):
        return "meat."
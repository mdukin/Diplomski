
class parrot:

    def __init__(self, name):
        self._name = name

    def name(self):
        return self._name

    def greet(self):
        return "hello!"

    def menu(self):
        return "seeds."
